#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define BUFFER_SIZE 5  // Size of the buffer

int buffer[BUFFER_SIZE];  // Shared buffer
int count = 0;           // Number of items in the buffer
int in = 0, out = 0;     // Indexes for producer and consumer

pthread_mutex_t mutex;   // Mutex for synchronizing access to the buffer
pthread_cond_t not_empty, not_full;  // Condition variables

// Producer function
void *producer(void *arg) {
    for (int i = 1; i <= 10; i++) {
        pthread_mutex_lock(&mutex);

        // Wait until the buffer has space
        while (count == BUFFER_SIZE) {
            pthread_cond_wait(&not_full, &mutex);
        }

        // Produce an item
        buffer[in] = i;
        printf("Producer: Produced item %d\n", i);
        in = (in + 1) % BUFFER_SIZE;
        count++;

        // Signal the consumer
        pthread_cond_signal(&not_empty);
        pthread_mutex_unlock(&mutex);

        sleep(1);  // Simulate production time
    }
    return NULL;
}

// Consumer function
void *consumer(void *arg) {
    for (int i = 1; i <= 10; i++) {
        pthread_mutex_lock(&mutex);

        // Wait until the buffer is not empty
        while (count == 0) {
            pthread_cond_wait(&not_empty, &mutex);
        }

        // Consume an item
        int item = buffer[out];
        printf("Consumer: Consumed item %d\n", item);
        out = (out + 1) % BUFFER_SIZE;
        count--;

        // Signal the producer
        pthread_cond_signal(&not_full);
        pthread_mutex_unlock(&mutex);

        sleep(2);  // Simulate consumption time
    }
    return NULL;
}

int main() {
    pthread_t prod_thread, cons_thread;

    // Initialize mutex and condition variables
    pthread_mutex_init(&mutex, NULL);
    pthread_cond_init(&not_empty, NULL);
    pthread_cond_init(&not_full, NULL);

    // Create producer and consumer threads
    pthread_create(&prod_thread, NULL, producer, NULL);
    pthread_create(&cons_thread, NULL, consumer, NULL);

    // Wait for threads to finish
    pthread_join(prod_thread, NULL);
    pthread_join(cons_thread, NULL);

    // Clean up
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&not_empty);
    pthread_cond_destroy(&not_full);

    return 0;
}
